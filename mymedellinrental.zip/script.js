const myVw = Math.max(document.documentElement.clientWidth);
const navButton = document.querySelector(".navigation__button");
const inputs = document.querySelectorAll(".form__input");
const whatsappLinks = document.querySelectorAll(".whatsapp-item");
const instagramLink = document.querySelector(".instagram-item");
const navList = document.querySelector(".navigation__list");
const nav = document.querySelector(".navigation");
const logo = document.querySelector(".navigation__logo");
const logoSmall = document.querySelector(".logo-small");

//SWIPER FUNCTIONALITY. slidesperview checks width > 900 then sets visible slides to 3 or 1
const swiper = new Swiper(".swiper-container", {
  spaceBetween: 30,
  slidesPerView: myVw > 900 ? 3 : 1,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});

myVw >= 700
  ? (instagramLink.href = "https://www.instagram.com/hablacolombiaspanish/")
  : (instagramLink.href = "instagram://user?username=hablacolombiaspanish");

if (myVw >= 1200) {
  navList.classList.remove("hidden");
  navButton.classList.add("hidden");
} else {
  navList.classList.add("hidden");
  navButton.classList.remove("hidden");
  logo.classList.add("hidden");
  logoSmall.classList.remove("hidden");
}

navButton.addEventListener("click", function () {
  navList.classList.toggle("hidden");
  nav.classList.toggle("active");
  logo.classList.toggle("hidden");
});
